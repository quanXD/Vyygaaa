import os
from pathlib import Path

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
REPORTS_DIR = BASE_DIR / "reports"

for d in [DATA_DIR, REPORTS_DIR]:
    d.mkdir(exist_ok=True)

THREADS = int(os.getenv("QT_THREADS", "40"))
TIMEOUT = int(os.getenv("QT_TIMEOUT", "12"))
RETRIES = int(os.getenv("QT_RETRIES", "2"))
CHAIN_DEPTH = int(os.getenv("QT_CHAIN_DEPTH", "3"))

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.2478.67",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 OPR/110.0.0.0",
]

PROXIES = []
for p in ["HTTP_PROXY", "HTTPS_PROXY", "SOCKS5_PROXY"]:
    v = os.getenv(p, "")
    if v:
        PROXIES.append(v)

THEME = {
    "primary": "cyan",
    "success": "green",
    "warning": "yellow",
    "danger": "red",
    "info": "blue",
    "muted": "dim",
    "gold": "gold1",
}

SEARCH_MODES = {
    "1": {"name": "Phone", "icon": "📱", "accepts": ["phone"]},
    "2": {"name": "IP Address", "icon": "🗺️", "accepts": ["ip"]},
    "3": {"name": "Domain", "icon": "🌐", "accepts": ["domain"]},
    "4": {"name": "Email", "icon": "📧", "accepts": ["email"]},
    "5": {"name": "Username", "icon": "👤", "accepts": ["username"]},
    "6": {"name": "Telegram", "icon": "✈️", "accepts": ["telegram"]},
    "7": {"name": "Full Recon", "icon": "🔱", "accepts": ["phone", "ip", "domain", "email", "username", "telegram"]},
}
