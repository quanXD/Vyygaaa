# QuantumTrace v1.0

The God of OSINT. Modular reconnaissance framework.

## Install

```bash
pip install -r requirements.txt
python main.py
```

## Menu

```
[1] Phone
[2] IP Address
[3] Domain
[4] Email
[5] Username
[6] Telegram
[7] Full Recon
[8] Settings
[9] History
[0] Exit
```

## Features

- 116+ modules with real API integrations
- SQLite database for persistent scan history
- Automatic chain enrichment
- Correlator: auto-links domain->IP, email->domain
- D3.js interactive graph in HTML reports
- Proxy rotation with retry + exponential backoff
- Target-type filtering: no more mixed reports
- Deep Telegram recon: tgstat, telemetr, wayback, cross-platform, dork search, paste search, username variations

## Settings

Set environment variables:
QT_THREADS, QT_TIMEOUT, QT_RETRIES, QT_CHAIN_DEPTH

## Reports

Auto-saved to ./reports/ as JSON and HTML with D3.js graph.
