#!/usr/bin/env python3
import sys
import asyncio
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from core.ui import QuantumUI
from core.engine import QuantumEngine
from core.logger import setup_logger
from core.reporter import Reporter
from core.db import QuantumDB
from config import SEARCH_MODES

log = setup_logger()

class QuantumTrace:
    def __init__(self):
        self.ui = QuantumUI()
        self.engine = QuantumEngine()

    async def run_mode(self, mode_key):
        mode = SEARCH_MODES.get(mode_key)
        if not mode:
            self.ui.alert("Invalid mode.", "danger")
            return
        target = self.ui.ask_target(mode["name"])
        if not target:
            self.ui.alert("No target provided.", "danger")
            return
        msg = "Launching recon for " + mode["name"] + " target: " + target
        self.ui.alert("\n" + msg, "info")
        results = await self.engine.run_mode(mode_key, target)
        self.ui.display_grouped(results)
        reporter = Reporter(self.engine.scan_id)
        paths = {}
        try:
            paths["JSON"] = reporter.save_json(target, mode["name"])
        except Exception as e:
            log.error("JSON save error: " + str(e))
        try:
            paths["HTML"] = reporter.save_html(target, mode["name"])
            # Derive graph path from HTML path
            html_path = str(paths["HTML"])
            graph_path = html_path.replace(".html", "_graph.html")
            paths["GRAPH"] = graph_path
        except Exception as e:
            log.error("HTML save error: " + str(e))
        corrs = len(self.engine.db.get_correlations(self.engine.scan_id))
        self.ui.final_stats(self.engine.stats, paths, corrs)

    def settings(self):
        self.ui.c.print("\n[bold]Settings[/]")
        self.ui.c.print("Edit config.py to set threads, timeout, chain depth.")
        self.ui.c.print("Environment variables: QT_THREADS, QT_TIMEOUT, QT_RETRIES, QT_CHAIN_DEPTH")

    def history(self):
        db = QuantumDB()
        scans = db.get_scans()
        if not scans:
            self.ui.c.print("\n[dim]No scan history found.[/]")
            return
        from rich.table import Table
        t = Table(title="Scan History")
        t.add_column("ID")
        t.add_column("Target")
        t.add_column("Mode")
        t.add_column("Started")
        t.add_column("Finished")
        t.add_column("Stats")
        for s in scans:
            t.add_row(str(s.get("id", "")), s.get("target", ""), s.get("mode", ""), s.get("started", ""), s.get("finished", ""), s.get("stats", "")[:50])
        self.ui.c.print(t)

    async def run(self):
        self.ui.banner()
        while True:
            choice = self.ui.main_menu()
            if choice in SEARCH_MODES:
                await self.run_mode(choice)
            elif choice == "8":
                self.settings()
            elif choice == "9":
                self.history()
            elif choice == "0":
                self.ui.alert("Exiting.", "info")
                break
            else:
                self.ui.alert("Invalid choice.", "danger")

if __name__ == "__main__":
    try:
        asyncio.run(QuantumTrace().run())
    except KeyboardInterrupt:
        print("\nInterrupted.")
