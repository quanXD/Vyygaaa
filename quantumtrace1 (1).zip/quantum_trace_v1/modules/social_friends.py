from modules.base import BaseModule

class Module(BaseModule):
    name = "social_friends"
    category = "general"
    accepts = ["username"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "username": target, "status": "Friend graph requires API access", "source": "social_friends"}]
