from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_virustotal"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "virustotal_url": f"https://www.virustotal.com/gui/ip-address/{target}",
            "source": "virustotal",
        }]
