from modules.base import BaseModule

class Module(BaseModule):
    name = "whois_asn"
    category = "general"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "ip": target, "asn_url": f"https://bgp.he.net/ip/{target}", "source": "whois_asn"}]
