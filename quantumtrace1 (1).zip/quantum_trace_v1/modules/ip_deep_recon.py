import socket
import ssl
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "ip_deep_recon"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        results = []
        async with __import__("aiohttp").ClientSession() as s:
            # Geo
            try:
                st, text = await fetch(s, "http://ip-api.com/json/" + target, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    results.append({
                        "_entity_type": "ip",
                        "_entity_value": target,
                        "ip": target,
                        "country": d.get("country", "N/A"),
                        "region": d.get("regionName", "N/A"),
                        "city": d.get("city", "N/A"),
                        "zip": d.get("zip", "N/A"),
                        "lat": str(d.get("lat", "N/A")),
                        "lon": str(d.get("lon", "N/A")),
                        "isp": d.get("isp", "N/A"),
                        "org": d.get("org", "N/A"),
                        "as": d.get("as", "N/A"),
                        "timezone": d.get("timezone", "N/A"),
                        "source": "ip-api",
                    })
            except:
                pass

            # ASN via BGPView
            try:
                st, text = await fetch(s, "https://api.bgpview.io/ip/" + target, headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    data = d.get("data", {})
                    for p in data.get("prefixes", [])[:3]:
                        results.append({
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "asn": p.get("asn", {}).get("asn", "N/A"),
                            "asn_name": p.get("asn", {}).get("name", "N/A"),
                            "asn_desc": p.get("asn", {}).get("description", "N/A"),
                            "prefix": p.get("prefix", "N/A"),
                            "source": "bgpview",
                        })
            except:
                pass

            # Reverse DNS
            try:
                hostname = socket.gethostbyaddr(target)[0]
                results.append({
                    "_entity_type": "ip",
                    "_entity_value": target,
                    "ip": target,
                    "hostname": hostname,
                    "source": "reverse_dns",
                })
            except:
                pass

            # Extended portscan (top 100)
            ports = [21,22,23,25,53,80,110,143,443,445,465,587,993,995,1723,3000,3306,3389,5432,5900,6379,8080,8443,9200,27017,5000,8000,8888,9000,10000]
            open_ports = []
            for port in ports:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1.0)
                    if sock.connect_ex((target, port)) == 0:
                        open_ports.append(str(port))
                    sock.close()
                except:
                    pass
            if open_ports:
                results.append({
                    "_entity_type": "ip",
                    "_entity_value": target,
                    "ip": target,
                    "open_ports": ", ".join(open_ports),
                    "source": "portscan",
                })

            # External links
            results.append({
                "_entity_type": "ip",
                "_entity_value": target,
                "ip": target,
                "shodan": "https://www.shodan.io/host/" + target,
                "censys": "https://search.censys.io/hosts/" + target,
                "virustotal": "https://www.virustotal.com/gui/ip-address/" + target,
                "abuseipdb": "https://www.abuseipdb.com/check/" + target,
                "bgp_he": "https://bgp.he.net/ip/" + target,
                "source": "external_refs",
            })

        return results if results else [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "status": "Limited data",
            "source": "deep_recon",
        }]
