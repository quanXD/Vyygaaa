import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "username_super_deep"
    category = "username"
    accepts = ["username"]

    async def run(self, target):
        u = target.lower().strip()
        results = []
        platforms = [
            ("github", "https://github.com/" + u),
            ("twitter", "https://twitter.com/" + u),
            ("instagram", "https://www.instagram.com/" + u),
            ("reddit", "https://www.reddit.com/user/" + u),
            ("tiktok", "https://www.tiktok.com/@" + u),
            ("linkedin", "https://www.linkedin.com/in/" + u),
            ("youtube", "https://www.youtube.com/@" + u),
            ("twitch", "https://www.twitch.tv/" + u),
            ("steam", "https://steamcommunity.com/id/" + u),
            ("vk", "https://vk.com/" + u),
            ("facebook", "https://www.facebook.com/" + u),
            ("pinterest", "https://www.pinterest.com/" + u),
            ("snapchat", "https://www.snapchat.com/add/" + u),
            ("soundcloud", "https://soundcloud.com/" + u),
            ("spotify", "https://open.spotify.com/user/" + u),
            ("deviantart", "https://www.deviantart.com/" + u),
            ("medium", "https://medium.com/@" + u),
            ("tumblr", "https://" + u + ".tumblr.com"),
            ("vimeo", "https://vimeo.com/" + u),
            ("quora", "https://www.quora.com/profile/" + u),
            ("flickr", "https://www.flickr.com/people/" + u),
            ("gitlab", "https://gitlab.com/" + u),
            ("keybase", "https://keybase.io/" + u),
            ("pastebin", "https://pastebin.com/u/" + u),
            ("hackernews", "https://news.ycombinator.com/user?id=" + u),
            ("okru", "https://ok.ru/" + u),
            ("mailru", "https://my.mail.ru/mail/" + u),
            ("tinder", "https://www.gotinder.com/@" + u),
            ("discord", "https://discord.com/users/" + u),
        ]
        async with aiohttp.ClientSession() as s:
            for name, url in platforms:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=8)
                    status = "UNKNOWN"
                    if st == 200:
                        if "not found" in text.lower() or "does not exist" in text.lower() or "page not found" in text.lower() or "sorry" in text.lower():
                            status = "NOT FOUND"
                        else:
                            status = "FOUND"
                    elif st == 404:
                        status = "NOT FOUND"
                    elif st == 403:
                        status = "BLOCKED"
                    if status == "FOUND":
                        results.append({
                            "_entity_type": "username",
                            "_entity_value": target,
                            "username": u,
                            "platform": name,
                            "url": url,
                            "status": status,
                            "source": "super_deep",
                        })
                except:
                    pass

            # Search mentions
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=\"" + u + "\"", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200:
                    urls = re.findall(r"https?://[^\s<>\"{}|\^`\[\]]+", text)
                    for found_url in set(urls)[:15]:
                        if u in found_url.lower():
                            results.append({
                                "_entity_type": "username",
                                "_entity_value": target,
                                "username": u,
                                "mention_url": found_url,
                                "source": "search_mention",
                            })
            except:
                pass

        return results if results else [{
            "_entity_type": "username",
            "_entity_value": target,
            "username": u,
            "status": "No public profiles",
            "source": "super_deep",
        }]
