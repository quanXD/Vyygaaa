import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_web_archive"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        url = f"https://web.archive.org/cdx/search/cdx?url=t.me/{u}&output=json&collapse=urlkey"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        snapshots = data[1:6]
                        for snap in snapshots:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "telegram",
                                    "_entity_value": target,
                                    "username": u,
                                    "snapshot_url": f"https://web.archive.org/web/{snap[1]}/{snap[2]}",
                                    "timestamp": snap[1],
                                    "original": snap[2],
                                    "source": "wayback_machine",
                                })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No archive snapshots",
                "source": "wayback_machine",
            })
        return results
