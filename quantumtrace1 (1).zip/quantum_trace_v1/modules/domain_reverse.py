import socket
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_reverse"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        try:
            ip = socket.gethostbyname(target)
            return [{
                "_entity_type": "ip",
                "_entity_value": ip,
                "domain": target,
                "ip": ip,
                "source": "dns_resolve",
            }]
        except:
            return [{
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "Resolve failed",
                "source": "dns_resolve",
            }]
