from modules.base import BaseModule

class Module(BaseModule):
    name = "ssl_ctlogs"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "domain": target, "ct_url": f"https://crt.sh/?q={target}", "source": "ct_logs"}]
