import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_email"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        results = []
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://{target}", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    emails = list(set(re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)))
                    for email in emails[:10]:
                        results.append({
                            "_entity_type": "email",
                            "_entity_value": email,
                            "domain": target,
                            "email": email,
                            "source": "web_scrape",
                        })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "No emails found",
                "source": "web_scrape",
            })
        return results
