import ssl
import socket
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_ssl"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        try:
            ctx = ssl.create_default_context()
            with socket.create_connection((target, 443), timeout=10) as sock:
                with ctx.wrap_socket(sock, server_hostname=target) as ssock:
                    cert = ssock.getpeercert()
                    cipher = ssock.cipher()
                    version = ssock.version()
                    return [{
                        "_entity_type": "domain",
                        "_entity_value": target,
                        "domain": target,
                        "subject": str(cert.get("subject")),
                        "issuer": str(cert.get("issuer")),
                        "not_before": str(cert.get("notBefore")),
                        "not_after": str(cert.get("notAfter")),
                        "serial": str(cert.get("serialNumber")),
                        "alt_names": ", ".join([x[1] for x in cert.get("subjectAltName", [])]),
                        "cipher": str(cipher),
                        "tls_version": version,
                        "source": "ssl",
                    }]
        except:
            return [{
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "SSL check failed",
                "source": "ssl",
            }]
