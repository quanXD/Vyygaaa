from modules.base import BaseModule

class Module(BaseModule):
    name = "email_social"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "status": "Social search via email requires specialized tools",
            "source": "social",
        }]
