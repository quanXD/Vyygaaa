import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_history"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        results = []
        url = f"https://web.archive.org/cdx/search/cdx?url={target}&output=json&collapse=urlkey"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        for snap in data[1:6]:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "domain",
                                    "_entity_value": target,
                                    "domain": target,
                                    "snapshot_url": f"https://web.archive.org/web/{snap[1]}/{snap[2]}",
                                    "timestamp": snap[1],
                                    "source": "wayback_machine",
                                })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "No archive data",
                "source": "wayback_machine",
            })
        return results
