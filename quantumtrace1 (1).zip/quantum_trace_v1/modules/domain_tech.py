import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_tech"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        results = []
        url = f"https://{target}"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                headers = {}
                tech = []
                if st == 200:
                    if "wp-content" in text or "wordpress" in text.lower():
                        tech.append("WordPress")
                    if "drupal" in text.lower():
                        tech.append("Drupal")
                    if "joomla" in text.lower():
                        tech.append("Joomla")
                    if "react" in text.lower():
                        tech.append("React")
                    if "vue" in text.lower():
                        tech.append("Vue.js")
                    if "angular" in text.lower():
                        tech.append("Angular")
                    if "laravel" in text.lower():
                        tech.append("Laravel")
                    if "django" in text.lower():
                        tech.append("Django")
                    if "flask" in text.lower():
                        tech.append("Flask")
                    if "express" in text.lower():
                        tech.append("Express")
                    if "next.js" in text.lower() or "_next" in text.lower():
                        tech.append("Next.js")
                    if "nginx" in text.lower():
                        tech.append("Nginx")
                    if "apache" in text.lower():
                        tech.append("Apache")
                    if "cloudflare" in text.lower():
                        tech.append("Cloudflare")
                    if "aws" in text.lower():
                        tech.append("AWS")
                    results.append({
                        "_entity_type": "domain",
                        "_entity_value": target,
                        "domain": target,
                        "technologies": ", ".join(tech) if tech else "N/A",
                        "status_code": st,
                        "source": "tech_scan",
                    })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "Tech scan failed",
                "source": "tech_scan",
            })
        return results
