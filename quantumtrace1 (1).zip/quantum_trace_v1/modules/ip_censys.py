from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_censys"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "censys_url": f"https://search.censys.io/hosts/{target}",
            "source": "censys",
        }]
