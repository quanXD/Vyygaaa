from modules.base import BaseModule

class Module(BaseModule):
    name = "darkweb_tor"
    category = "general"
    accepts = ["domain", "ip"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "Tor search requires onion access", "source": "tor"}]
