import re
import socket
import smtplib
from modules.base import BaseModule

class Module(BaseModule):
    name = "email_verify"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        if not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", target):
            return [{"_entity_type": "email", "_entity_value": target, "email": target, "valid": "Invalid format", "source": "verify"}]
        domain = target.split("@")[1]
        try:
            mx = socket.gethostbyname(domain)
            return [{
                "_entity_type": "email",
                "_entity_value": target,
                "email": target,
                "valid": "Format valid, domain resolves",
                "mx": mx,
                "source": "verify",
            }]
        except:
            return [{
                "_entity_type": "email",
                "_entity_value": target,
                "email": target,
                "valid": "Domain does not resolve",
                "source": "verify",
            }]
