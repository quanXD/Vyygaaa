from modules.base import BaseModule

class Module(BaseModule):
    name = "tech_stack"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "domain": target, "status": "Use Domain mode for tech stack", "source": "tech_stack"}]
