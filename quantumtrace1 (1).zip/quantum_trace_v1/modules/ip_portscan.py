import socket
from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_portscan"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5432, 5900, 8080, 8443, 9200]
        open_ports = []
        for port in ports:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(1.5)
                result = sock.connect_ex((target, port))
                if result == 0:
                    open_ports.append(str(port))
                sock.close()
            except:
                pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "open_ports": ", ".join(open_ports) if open_ports else "None detected",
            "source": "portscan",
        }]
