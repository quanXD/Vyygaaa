from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_shodan"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "shodan_url": f"https://www.shodan.io/host/{target}",
            "source": "shodan",
        }]
