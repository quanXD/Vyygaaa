import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_tgstat"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        urls = [
            f"https://tgstat.ru/channel/@{u}",
            f"https://tgstat.ru/search?q=@{u}",
        ]
        async with aiohttp.ClientSession() as s:
            for url in urls:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        title = re.search(r'<title>([^<]+)</title>', text)
                        desc = re.search(r'meta name="description" content="([^"]+)"', text)
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "username": u,
                            "url": url,
                            "title": title.group(1).strip() if title else "N/A",
                            "description": desc.group(1).strip() if desc else "N/A",
                            "source": "tgstat.ru",
                        })
                        related = re.findall(r't\.me/([a-zA-Z0-9_]{5,32})', text)
                        for rel in set(related):
                            if rel != u:
                                results.append({
                                    "_entity_type": "telegram",
                                    "_entity_value": target,
                                    "related_username": rel,
                                    "url": f"https://t.me/{rel}",
                                    "source": "tgstat_related",
                                })
                except:
                    pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No tgstat data",
                "source": "tgstat.ru",
            })
        return results
