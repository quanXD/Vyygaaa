import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, norm_phone

class Module(BaseModule):
    name = "phone_deep_recon"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = norm_phone(target)
        results = []
        async with aiohttp.ClientSession() as s:
            # Web search
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=\"" + num + "\"", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200:
                    urls = re.findall(r"https?://[^\s<>\"{}|\^`\[\]]+", text)
                    for u in set(urls)[:15]:
                        results.append({
                            "_entity_type": "phone",
                            "_entity_value": target,
                            "phone": target,
                            "mention_url": u,
                            "source": "web_search",
                        })
            except:
                pass

            # WhatsApp direct
            results.append({
                "_entity_type": "phone",
                "_entity_value": target,
                "phone": target,
                "whatsapp": "https://wa.me/" + num.replace("+", ""),
                "source": "whatsapp_direct",
            })

            # Telegram link
            results.append({
                "_entity_type": "phone",
                "_entity_value": target,
                "phone": target,
                "telegram_possible": "https://t.me/" + num,
                "source": "telegram_heuristic",
            })

            # Country detection
            country = "Unknown"
            if num.startswith("+1"):
                country = "USA/Canada"
            elif num.startswith("+7"):
                country = "Russia/Kazakhstan"
            elif num.startswith("+44"):
                country = "UK"
            elif num.startswith("+49"):
                country = "Germany"
            elif num.startswith("+33"):
                country = "France"
            elif num.startswith("+39"):
                country = "Italy"
            elif num.startswith("+34"):
                country = "Spain"
            elif num.startswith("+86"):
                country = "China"
            elif num.startswith("+81"):
                country = "Japan"
            elif num.startswith("+82"):
                country = "South Korea"
            elif num.startswith("+91"):
                country = "India"
            elif num.startswith("+55"):
                country = "Brazil"
            elif num.startswith("+61"):
                country = "Australia"
            elif num.startswith("+380"):
                country = "Ukraine"
            elif num.startswith("+375"):
                country = "Belarus"
            elif num.startswith("+48"):
                country = "Poland"
            elif num.startswith("+90"):
                country = "Turkey"
            elif num.startswith("+31"):
                country = "Netherlands"
            elif num.startswith("+41"):
                country = "Switzerland"
            elif num.startswith("+46"):
                country = "Sweden"
            elif num.startswith("+47"):
                country = "Norway"
            elif num.startswith("+45"):
                country = "Denmark"
            elif num.startswith("+358"):
                country = "Finland"
            results.append({
                "_entity_type": "phone",
                "_entity_value": target,
                "phone": target,
                "country": country,
                "source": "prefix_lookup",
            })

        return results
