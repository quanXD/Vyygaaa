from modules.base import BaseModule

class Module(BaseModule):
    name = "cve_search"
    category = "general"
    accepts = ["domain", "ip"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "cve_url": f"https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword={target}", "source": "cve"}]
