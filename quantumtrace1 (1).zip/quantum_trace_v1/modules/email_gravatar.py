import hashlib
import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "email_gravatar"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        h = hashlib.md5(target.lower().strip().encode()).hexdigest()
        url = f"https://www.gravatar.com/{h}"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://www.gravatar.com/{h}.json", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    entry = d.get("entry", [{}])[0]
                    return [{
                        "_entity_type": "email",
                        "_entity_value": target,
                        "email": target,
                        "gravatar_hash": h,
                        "profile": entry.get("profileUrl", "N/A"),
                        "name": entry.get("displayName", "N/A"),
                        "photo": entry.get("thumbnailUrl", "N/A"),
                        "source": "gravatar",
                    }]
        except:
            pass
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "gravatar_hash": h,
            "profile": "N/A",
            "source": "gravatar",
        }]
