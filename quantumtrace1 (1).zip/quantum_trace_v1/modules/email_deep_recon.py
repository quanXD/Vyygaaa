import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "email_deep_recon"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        results = []
        user = target.split("@")[0]
        domain = target.split("@")[-1]
        async with aiohttp.ClientSession() as s:
            # Search for email mentions
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=\"" + target + "\"", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200:
                    urls = re.findall(r"https?://[^\s<>\"{}|\^`\[\]]+", text)
                    for u in set(urls)[:15]:
                        results.append({
                            "_entity_type": "email",
                            "_entity_value": target,
                            "email": target,
                            "mention_url": u,
                            "source": "web_search",
                        })
            except:
                pass

            # Pastebin / rentry dork
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=site:pastebin.com+\"" + target + "\"", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    pastes = re.findall(r"pastebin\.com/\w+", text)
                    for p in set(pastes)[:5]:
                        results.append({
                            "_entity_type": "email",
                            "_entity_value": target,
                            "email": target,
                            "paste_url": "https://" + p,
                            "source": "pastebin_dork",
                        })
            except:
                pass

            # GitHub search for email
            try:
                st, text = await fetch(s, "https://api.github.com/search/users?q=" + target + "+in:email", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    import json
                    d = json.loads(text)
                    for item in d.get("items", [])[:5]:
                        results.append({
                            "_entity_type": "username",
                            "_entity_value": item.get("login", ""),
                            "email": target,
                            "github_user": item.get("login", ""),
                            "url": item.get("html_url", ""),
                            "source": "github_search",
                        })
            except:
                pass

            # Gravatar
            try:
                import hashlib
                h = hashlib.md5(target.lower().strip().encode()).hexdigest()
                st, text = await fetch(s, "https://www.gravatar.com/" + h + ".json", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    import json
                    d = json.loads(text)
                    entry = d.get("entry", [{}])[0]
                    results.append({
                        "_entity_type": "email",
                        "_entity_value": target,
                        "email": target,
                        "gravatar_hash": h,
                        "profile": entry.get("profileUrl", "N/A"),
                        "name": entry.get("displayName", "N/A"),
                        "photo": entry.get("thumbnailUrl", "N/A"),
                        "source": "gravatar",
                    })
            except:
                pass

            # Extract username from email
            results.append({
                "_entity_type": "username",
                "_entity_value": user,
                "email": target,
                "derived_username": user,
                "domain": domain,
                "source": "email_parse",
            })

        return results if results else [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "status": "Limited public data",
            "source": "deep_recon",
        }]
