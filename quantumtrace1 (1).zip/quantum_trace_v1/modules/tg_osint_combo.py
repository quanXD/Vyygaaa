import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username, tg_variations

class Module(BaseModule):
    name = "tg_osint_combo"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        async with aiohttp.ClientSession() as s:
            # Main profile
            try:
                st, text = await fetch(s, "https://t.me/" + u, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    name = "N/A"
                    bio = "N/A"
                    photo = "No"
                    premium = "No"
                    m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                    if m:
                        name = m.group(1).strip()
                    m2 = re.search(r'<div class="tgme_page_extra">([^<]+)</div>', text)
                    if m2:
                        bio = m2.group(1).strip()
                    if "tgme_page_photo_image" in text:
                        photo = "Yes"
                    if " Premium" in text or "premium" in text.lower():
                        premium = "Yes"
                    subscribers = "N/A"
                    m3 = re.search(r'(\d+[\s\d]*\d*)\s*(subscribers|members)', text, re.I)
                    if m3:
                        subscribers = m3.group(1).strip()
                    results.append({
                        "_entity_type": "telegram",
                        "_entity_value": target,
                        "username": u,
                        "name": name,
                        "bio": bio,
                        "photo": photo,
                        "premium": premium,
                        "subscribers": subscribers,
                        "url": "https://t.me/" + u,
                        "source": "t.me_profile",
                    })
            except:
                pass

            # Username variations
            for var in tg_variations(u)[:6]:
                if var == u:
                    continue
                try:
                    st, text = await fetch(s, "https://t.me/" + var, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=8)
                    if st == 200 and "tgme_page_title" in text:
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        name = m.group(1).strip() if m else "N/A"
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "variation": var,
                            "name": name,
                            "url": "https://t.me/" + var,
                            "source": "username_variation",
                        })
                except:
                    pass

            # Tgstat
            try:
                st, text = await fetch(s, "https://tgstat.ru/channel/@" + u, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    title = re.search(r'<title>([^<]+)</title>', text)
                    results.append({
                        "_entity_type": "telegram",
                        "_entity_value": target,
                        "username": u,
                        "tgstat_title": title.group(1).strip() if title else "N/A",
                        "url": "https://tgstat.ru/channel/@" + u,
                        "source": "tgstat",
                    })
                    related = re.findall(r't\.me/([a-zA-Z0-9_]{5,32})', text)
                    for rel in set(related):
                        if rel != u:
                            results.append({
                                "_entity_type": "telegram",
                                "_entity_value": target,
                                "related_username": rel,
                                "url": "https://t.me/" + rel,
                                "source": "tgstat_related",
                            })
            except:
                pass

            # Telemetr
            try:
                st, text = await fetch(s, "https://telemetr.me/" + u, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    title = re.search(r'<title>([^<]+)</title>', text)
                    subs = re.search(r'(\d+[\s\d]*\d*)\s*subscribers', text, re.I)
                    results.append({
                        "_entity_type": "telegram",
                        "_entity_value": target,
                        "username": u,
                        "telemetr_title": title.group(1).strip() if title else "N/A",
                        "telemetr_subs": subs.group(1).strip() if subs else "N/A",
                        "url": "https://telemetr.me/" + u,
                        "source": "telemetr",
                    })
            except:
                pass

            # Wayback
            try:
                st, text = await fetch(s, "https://web.archive.org/cdx/search/cdx?url=t.me/" + u + "&output=json&collapse=urlkey", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        for snap in data[1:4]:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "telegram",
                                    "_entity_value": target,
                                    "username": u,
                                    "snapshot": "https://web.archive.org/web/" + snap[1] + "/" + snap[2],
                                    "date": snap[1],
                                    "source": "wayback",
                                })
            except:
                pass

            # Cross-platform via search
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=site:github.com+" + u, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200 and "github.com/" + u in text:
                    results.append({
                        "_entity_type": "username",
                        "_entity_value": u,
                        "platform": "github",
                        "url": "https://github.com/" + u,
                        "source": "cross_platform",
                    })
            except:
                pass

            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=site:twitter.com+" + u, headers={"User-Agent": get_UA()}, proxy=get_proxy(), timeout=10)
                if st == 200 and "twitter.com/" + u in text:
                    results.append({
                        "_entity_type": "username",
                        "_entity_value": u,
                        "platform": "twitter",
                        "url": "https://twitter.com/" + u,
                        "source": "cross_platform",
                    })
            except:
                pass

        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No public data found",
                "source": "combo",
            })
        return results
