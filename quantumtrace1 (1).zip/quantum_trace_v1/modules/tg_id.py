import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_id"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "username": u,
            "user_id": "N/A",
            "method": "web_scrape",
            "note": "User ID requires Telegram API or bot interaction",
        }]
