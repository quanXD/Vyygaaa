import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "domain_subdomain"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        found = []
        try:
            async with aiohttp.ClientSession() as s:
                status, text = await fetch(s, f"https://crt.sh/?q=%.{target}&output=json", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if status == 200:
                    import json
                    d = json.loads(text)
                    seen = set()
                    for entry in d[:50]:
                        name = entry.get("name_value", "").strip()
                        if name and name not in seen:
                            seen.add(name)
                            found.append({"domain": target, "subdomain": name, "source": "crt.sh"})
                    if found:
                        return found
        except:
            pass
        subs = ["www", "mail", "ftp", "api", "dev", "staging", "admin", "blog", "shop", "vpn", "cdn", "img", "static", "app", "m", "support", "help", "docs", "status", "git", "test", "demo", "portal", "secure", "api-v2", "cdn2", "static2", "old", "new", "beta", "alpha", "prod", "backup", "db", "ns1", "ns2", "mx", "smtp", "pop", "imap", "webmail", "remote", "server", "cloud", "storage", "files", "media", "video", "img1", "img2", "assets", "js", "css", "ws", "graphql", "rest", "oauth", "auth", "login", "account", "user", "member", "partner", "career", "press", "news", "about", "contact", "feedback", "helpdesk", "forum", "community", "chat", "live", "stream", "events", "calendar", "booking", "order", "cart", "checkout", "payment", "billing", "invoice", "subscription", "preferences", "settings", "config", "dashboard", "panel", "cp", "manage", "manager", "root", "staff", "team", "employee", "hr", "finance", "accounting", "legal", "compliance", "security", "ops", "operations", "it", "tech", "engineering", "developer", "devops", "sre", "infra", "infrastructure", "network", "datacenter", "hosting", "edge", "cache", "proxy", "gateway", "lb", "router", "firewall", "ssl", "cert", "dns", "spf", "dkim", "dmarc", "mta-sts", "tls-rpt", "caa", "soa", "ptr", "srv", "txt", "forward", "mail2", "mail3", "smtp2", "smtp3", "pop2", "pop3", "imap2", "imap3", "webmail2", "owa", "exchange", "office365", "o365", "google", "gmail", "gsuite", "workspace", "aws", "amazon", "ec2", "s3", "cloudfront", "route53", "elb", "alb", "nlb", "rds", "aurora", "dynamodb", "lambda", "apigateway", "sns", "sqs", "ses", "iam", "kms", "cloudwatch", "logs", "monitoring", "alert", "notification", "pagerduty", "datadog", "newrelic", "splunk", "elastic", "elk", "kibana", "grafana", "prometheus", "jaeger", "zipkin", "trace", "tracing", "apm", "observability", "telemetry", "metrics", "metric", "log", "logging", "logger", "audit", "auditing", "gdpr", "hipaa", "pci", "soc2", "iso27001", "nist", "owasp", "cve", "vulnerability", "vuln", "scan", "scanner", "scanning", "pentest", "penetration", "redteam", "blueteam", "threat", "threatintel", "ti", "osint", "intel", "intelligence", "recon", "reconnaissance", "investigation", "investigate", "forensic", "forensics", "incident", "response", "soc", "siem", "soar", "xdr", "edr", "mdr", "ndr", "ueba", "dlp", "casb", "sase", "zero", "trust", "ztna", "sdp", "vpn2", "sdwan", "mfa", "2fa", "sso", "oauth2", "oidc", "saml", "ldap", "ad", "activedirectory", "domaincontroller", "fs", "fileserver", "print", "printer", "fax", "voip", "pbx", "asterisk", "freepbx", "3cx", "teams", "zoom", "webex", "slack", "discord", "mattermost", "rocket", "matrix", "element", "signal", "whatsapp", "viber", "wechat", "line", "kakao", "telegram", "tg", "vk", "ok", "facebook", "instagram", "twitter", "x", "tiktok", "youtube", "yt", "twitch", "reddit", "linkedin", "pinterest", "snapchat", "tumblr", "flickr", "vimeo", "soundcloud", "spotify", "apple", "itunes", "appstore", "playstore", "googleplay"]
        for sub in subs:
            found.append({"domain": target, "subdomain": f"{sub}.{target}", "source": "dictionary"})
        return found
