from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_iot"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "status": "IoT search requires Shodan/Censys API",
            "source": "iot",
        }]
