import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_cross_platform"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        platforms = [
            ("twitter", f"https://nitter.net/search?f=tweets&q={u}"),
            ("reddit", f"https://www.reddit.com/search/?q={u}"),
            ("github", f"https://github.com/search?q={u}&type=users"),
        ]
        async with aiohttp.ClientSession() as s:
            for platform, url in platforms:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        found = "possible"
                        if platform == "twitter" and "No items found" not in text:
                            found = "likely"
                        elif platform == "reddit" and "search-results" in text:
                            found = "likely"
                        elif platform == "github" and "user-list-item" in text:
                            found = "likely"
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "username": u,
                            "platform": platform,
                            "same_username": found,
                            "url": url,
                            "source": "cross_platform",
                        })
                except:
                    pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No cross-platform data",
                "source": "cross_platform",
            })
        return results
