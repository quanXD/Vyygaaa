from modules.base import BaseModule

class Module(BaseModule):
    name = "archive_is"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "domain": target, "archive_url": f"https://archive.is/{target}", "source": "archive.is"}]
