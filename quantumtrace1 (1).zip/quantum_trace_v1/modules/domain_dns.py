import dns.resolver
from modules.base import BaseModule

class Module(BaseModule):
    name = "domain_dns"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        results = []
        records = ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME"]
        for rtype in records:
            try:
                answers = dns.resolver.resolve(target, rtype)
                for ans in answers:
                    results.append({
                        "_entity_type": "domain",
                        "_entity_value": target,
                        "domain": target,
                        "type": rtype,
                        "value": str(ans),
                        "source": "dns",
                    })
            except:
                pass
        if not results:
            results.append({
                "_entity_type": "domain",
                "_entity_value": target,
                "domain": target,
                "status": "No DNS records",
                "source": "dns",
            })
        return results
