import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "ip_abuse"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        results = []
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://api.abuseipdb.com/api/v2/check?ipAddress={target}", headers={"User-Agent": get_ua(), "Key": ""}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    data = d.get("data", {})
                    results.append({
                        "_entity_type": "ip",
                        "_entity_value": target,
                        "ip": target,
                        "abuse_confidence": data.get("abuseConfidencePercentage", "N/A"),
                        "country": data.get("countryCode", "N/A"),
                        "isp": data.get("isp", "N/A"),
                        "usage_type": data.get("usageType", "N/A"),
                        "domain": data.get("domain", "N/A"),
                        "total_reports": data.get("totalReports", "N/A"),
                        "last_reported": data.get("lastReportedAt", "N/A"),
                        "source": "abuseipdb",
                    })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "ip",
                "_entity_value": target,
                "ip": target,
                "status": "No abuse data (API key required for full data)",
                "source": "abuseipdb",
            })
        return results
