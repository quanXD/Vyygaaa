from modules.base import BaseModule

class Module(BaseModule):
    name = "social_common"
    category = "general"
    accepts = ["username"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "username": target, "status": "Use Username mode for social search", "source": "social_common"}]
