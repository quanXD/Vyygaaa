import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_pastebin"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        sources = [
            f"https://html.duckduckgo.com/html/?q=site:pastebin.com+%22{u}%22",
            f"https://html.duckduckgo.com/html/?q=site:rentry.co+%22{u}%22",
        ]
        async with aiohttp.ClientSession() as s:
            for url in sources:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        pastes = re.findall(r'(pastebin\.com/\w+|rentry\.co/\w+)', text)
                        for paste in set(pastes):
                            results.append({
                                "_entity_type": "telegram",
                                "_entity_value": target,
                                "username": u,
                                "paste_url": f"https://{paste}",
                                "source": "paste_search",
                            })
                except:
                    pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No paste mentions",
                "source": "paste_search",
            })
        return results
