from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_exif"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "EXIF analysis requires image files", "source": "exif"}]
