import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username, tg_variations

class Module(BaseModule):
    name = "tg_super_deep"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        async with aiohttp.ClientSession() as s:
            sources = [
                ("https://t.me/" + u, "t.me"),
                ("https://tgstat.ru/channel/@" + u, "tgstat"),
                ("https://tgstat.ru/search?q=@" + u, "tgstat_search"),
                ("https://telemetr.me/" + u, "telemetr"),
                ("https://tchannels.me/" + u, "tchannels"),
                ("https://combot.org/telegram/top/channels?search=" + u, "combot"),
            ]
            for url, src in sources:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        title = re.search(r'<title>([^<]+)</title>', text)
                        desc = re.search(r'<meta[^>]+description[^>]+content="([^"]+)"', text, re.I)
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "username": u,
                            "source": src,
                            "url": url,
                            "title": title.group(1).strip() if title else "N/A",
                            "description": desc.group(1).strip() if desc else "N/A",
                        })
                        # Extract related usernames
                        related = re.findall(r't\.me/([a-zA-Z0-9_]{5,32})', text)
                        for rel in set(related):
                            if rel != u:
                                results.append({
                                    "_entity_type": "telegram",
                                    "_entity_value": target,
                                    "related_username": rel,
                                    "url": "https://t.me/" + rel,
                                    "source": src + "_related",
                                })
                except:
                    pass

            # Username variations
            for var in tg_variations(u)[:8]:
                if var == u:
                    continue
                try:
                    st, text = await fetch(s, "https://t.me/" + var, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=8)
                    if st == 200 and "tgme_page_title" in text:
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        name = m.group(1).strip() if m else "N/A"
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "variation": var,
                            "name": name,
                            "url": "https://t.me/" + var,
                            "source": "variation",
                        })
                except:
                    pass

            # Wayback
            try:
                st, text = await fetch(s, "https://web.archive.org/cdx/search/cdx?url=t.me/" + u + "&output=json&collapse=urlkey", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        for snap in data[1:6]:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "telegram",
                                    "_entity_value": target,
                                    "snapshot": "https://web.archive.org/web/" + snap[1] + "/" + snap[2],
                                    "date": snap[1],
                                    "source": "wayback",
                                })
            except:
                pass

            # Cross-platform via search
            for platform, search_url in [
                ("github", "https://html.duckduckgo.com/html/?q=site:github.com+" + u),
                ("twitter", "https://html.duckduckgo.com/html/?q=site:twitter.com+" + u),
                ("instagram", "https://html.duckduckgo.com/html/?q=site:instagram.com+" + u),
                ("reddit", "https://html.duckduckgo.com/html/?q=site:reddit.com+" + u),
            ]:
                try:
                    st, text = await fetch(s, search_url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        results.append({
                            "_entity_type": "username",
                            "_entity_value": u,
                            "platform": platform,
                            "same_username": "possible",
                            "search_url": search_url,
                            "source": "cross_platform",
                        })
                except:
                    pass

        return results if results else [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "username": u,
            "status": "No public data",
            "source": "super_deep",
        }]
