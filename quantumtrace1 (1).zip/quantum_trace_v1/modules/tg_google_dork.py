import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_google_dork"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        dorks = [
            "site:t.me " + u,
            "site:tgstat.ru " + u,
            "site:telemetr.me " + u,
            '"@' + u + '" telegram',
        ]
        async with aiohttp.ClientSession() as s:
            for dork in dorks:
                try:
                    url = "https://html.duckduckgo.com/html/?q=" + dork.replace(" ", "+")
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    if st == 200:
                        links = re.findall(r"t\.me/([a-zA-Z0-9_]{5,32})", text)
                        for link in set(links):
                            results.append({
                                "_entity_type": "telegram",
                                "_entity_value": target,
                                "username": u,
                                "found_username": link,
                                "dork": dork,
                                "url": "https://t.me/" + link,
                                "source": "dork_search",
                            })
                except:
                    pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No dork results",
                "source": "dork_search",
            })
        return results
