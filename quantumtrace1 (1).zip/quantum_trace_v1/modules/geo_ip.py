from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_ip"
    category = "general"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "ip": target, "status": "Use IP Address mode for geo data", "source": "geo_ip"}]
