from modules.base import BaseModule

class Module(BaseModule):
    name = "metadata_image"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "Image metadata requires file access", "source": "metadata_image"}]
