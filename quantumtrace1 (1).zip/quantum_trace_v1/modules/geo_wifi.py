from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_wifi"
    category = "general"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "WiFi geolocation requires BSSID data", "source": "wifi"}]
