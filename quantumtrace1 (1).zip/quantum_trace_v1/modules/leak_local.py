from modules.base import BaseModule

class Module(BaseModule):
    name = "leak_local"
    category = "general"
    accepts = ["email", "username"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "Local leak DB not configured", "source": "local_leak"}]
