from modules.base import BaseModule

class Module(BaseModule):
    name = "leak_hibp"
    category = "general"
    accepts = ["email"]

    async def run(self, target):
        return [{"_entity_type": "email", "_entity_value": target, "email": target, "status": "Use Email mode for HIBP data", "source": "hibp"}]
