import socket
from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_reverse"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        try:
            hostname = socket.gethostbyaddr(target)[0]
            return [{
                "_entity_type": "ip",
                "_entity_value": target,
                "ip": target,
                "hostname": hostname,
                "source": "reverse_dns",
            }]
        except:
            return [{
                "_entity_type": "ip",
                "_entity_value": target,
                "ip": target,
                "hostname": "N/A",
                "source": "reverse_dns",
            }]
