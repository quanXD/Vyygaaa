import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_messages"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "username": u,
            "status": "Public messages require direct API or client access",
            "method": "web_scrape",
            "note": "Use Telegram client for full message history",
        }]
