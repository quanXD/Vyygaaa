import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, norm_phone

class Module(BaseModule):
    name = "phone_basic"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = norm_phone(target)
        results = []
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://html.duckduckgo.com/html/?q={num}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    results.append({
                        "_entity_type": "phone",
                        "_entity_value": target,
                        "phone": target,
                        "normalized": num,
                        "search_status": "Search completed",
                        "source": "web_search",
                    })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "phone",
                "_entity_value": target,
                "phone": target,
                "normalized": num,
                "status": "Basic lookup completed",
                "source": "heuristic",
            })
        return results
