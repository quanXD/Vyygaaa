from modules.base import BaseModule

class Module(BaseModule):
    name = "iot_search"
    category = "general"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "IoT search requires Shodan/Censys API", "source": "iot"}]
