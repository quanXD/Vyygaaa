from modules.base import BaseModule

class Module(BaseModule):
    name = "archive_cache"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "domain": target, "cache_url": f"https://webcache.googleusercontent.com/search?q=cache:{target}", "source": "google_cache"}]
