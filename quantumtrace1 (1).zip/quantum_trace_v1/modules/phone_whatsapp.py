from modules.base import BaseModule
from core.utils import norm_phone

class Module(BaseModule):
    name = "phone_whatsapp"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = norm_phone(target)
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "whatsapp_url": f"https://wa.me/{num.replace('+', '')}",
            "source": "whatsapp",
        }]
