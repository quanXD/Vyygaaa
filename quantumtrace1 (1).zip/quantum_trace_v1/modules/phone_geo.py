from modules.base import BaseModule
from core.utils import norm_phone

class Module(BaseModule):
    name = "phone_geo"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = norm_phone(target)
        country = "Unknown"
        if num.startswith("+1"):
            country = "USA/Canada"
        elif num.startswith("+7"):
            country = "Russia/Kazakhstan"
        elif num.startswith("+44"):
            country = "UK"
        elif num.startswith("+49"):
            country = "Germany"
        elif num.startswith("+33"):
            country = "France"
        elif num.startswith("+39"):
            country = "Italy"
        elif num.startswith("+34"):
            country = "Spain"
        elif num.startswith("+86"):
            country = "China"
        elif num.startswith("+81"):
            country = "Japan"
        elif num.startswith("+82"):
            country = "South Korea"
        elif num.startswith("+91"):
            country = "India"
        elif num.startswith("+55"):
            country = "Brazil"
        elif num.startswith("+61"):
            country = "Australia"
        elif num.startswith("+380"):
            country = "Ukraine"
        elif num.startswith("+375"):
            country = "Belarus"
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "normalized": num,
            "country": country,
            "source": "prefix_lookup",
        }]
