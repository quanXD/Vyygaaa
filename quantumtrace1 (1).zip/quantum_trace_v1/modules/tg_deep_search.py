import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username, tg_variations

class Module(BaseModule):
    name = "tg_deep_search"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        variations = tg_variations(u)

        async with aiohttp.ClientSession() as s:
            for var in variations[:8]:
                url = f"https://t.me/{var}"
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=8)
                    if st == 200 and "tgme_page_title" in text:
                        m = re.search(r'<div class="tgme_page_title[^"]*"><strong>([^<]+)</strong>', text)
                        name = m.group(1).strip() if m else "N/A"
                        results.append({
                            "_entity_type": "telegram",
                            "_entity_value": target,
                            "variation": var,
                            "url": url,
                            "exists": "Yes",
                            "name": name,
                            "source": "t.me_variation",
                        })
                except:
                    pass

        search_engines = [
            f"https://html.duckduckgo.com/html/?q=site:t.me+{u}",
            f"https://html.duckduckgo.com/html/?q=telegram+{u}",
        ]
        for se_url in search_engines:
            try:
                st, text = await fetch(s, se_url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    links = re.findall(r't\.me/([a-zA-Z0-9_]{5,32})', text)
                    for link in set(links):
                        if link not in [r.get("variation", "") for r in results]:
                            results.append({
                                "_entity_type": "telegram",
                                "_entity_value": target,
                                "related_username": link,
                                "url": f"https://t.me/{link}",
                                "source": "search_engine",
                            })
            except:
                pass

        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No additional data found",
                "source": "deep_search",
            })
        return results
