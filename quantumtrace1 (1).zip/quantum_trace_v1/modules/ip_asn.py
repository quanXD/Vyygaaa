import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "ip_asn"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://api.bgpview.io/ip/{target}", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    data = d.get("data", {})
                    prefixes = data.get("prefixes", [])
                    if prefixes:
                        p = prefixes[0]
                        return [{
                            "_entity_type": "ip",
                            "_entity_value": target,
                            "ip": target,
                            "asn": p.get("asn", {}).get("asn", "N/A"),
                            "asn_name": p.get("asn", {}).get("name", "N/A"),
                            "asn_description": p.get("asn", {}).get("description", "N/A"),
                            "prefix": p.get("prefix", "N/A"),
                            "source": "bgpview",
                        }]
        except:
            pass
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "asn": "N/A",
            "asn_name": "N/A",
            "source": "failed",
        }]
