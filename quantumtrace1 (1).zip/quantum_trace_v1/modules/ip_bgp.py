from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_bgp"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "bgp_url": f"https://bgp.he.net/ip/{target}",
            "source": "bgp.he.net",
        }]
