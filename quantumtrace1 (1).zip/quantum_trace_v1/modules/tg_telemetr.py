import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_telemetr"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        results = []
        url = f"https://telemetr.me/{u}"
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    title = re.search(r'<title>([^<]+)</title>', text)
                    subs = re.search(r'(\d+[\s\d]*\d*)\s*subscribers', text, re.I)
                    results.append({
                        "_entity_type": "telegram",
                        "_entity_value": target,
                        "username": u,
                        "url": url,
                        "title": title.group(1).strip() if title else "N/A",
                        "subscribers": subs.group(1).strip() if subs else "N/A",
                        "source": "telemetr.me",
                    })
        except:
            pass
        if not results:
            results.append({
                "_entity_type": "telegram",
                "_entity_value": target,
                "username": u,
                "status": "No telemetr data",
                "source": "telemetr.me",
            })
        return results
