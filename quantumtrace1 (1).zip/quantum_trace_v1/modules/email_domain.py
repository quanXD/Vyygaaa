from modules.base import BaseModule
from core.utils import norm_domain

class Module(BaseModule):
    name = "email_domain"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        domain = target.split("@")[-1]
        return [{
            "_entity_type": "domain",
            "_entity_value": domain,
            "email": target,
            "domain": domain,
            "source": "email_parse",
        }]
