import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "email_github"
    category = "email"
    accepts = ["email"]

    async def run(self, target):
        try:
            async with aiohttp.ClientSession() as s:
                st, text = await fetch(s, f"https://api.github.com/search/users?q={target}+in:email", headers={"User-Agent": get_ua()}, proxy=get_proxy())
                if st == 200:
                    import json
                    d = json.loads(text)
                    items = d.get("items", [])
                    results = []
                    for item in items[:5]:
                        results.append({
                            "_entity_type": "username",
                            "_entity_value": item.get("login", ""),
                            "email": target,
                            "github_user": item.get("login", ""),
                            "url": item.get("html_url", ""),
                            "source": "github",
                        })
                    return results if results else [{
                        "_entity_type": "email",
                        "_entity_value": target,
                        "email": target,
                        "status": "No GitHub matches",
                        "source": "github",
                    }]
        except:
            pass
        return [{
            "_entity_type": "email",
            "_entity_value": target,
            "email": target,
            "status": "GitHub search failed",
            "source": "github",
        }]
