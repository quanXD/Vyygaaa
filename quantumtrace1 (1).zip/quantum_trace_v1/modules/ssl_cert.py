from modules.base import BaseModule

class Module(BaseModule):
    name = "ssl_cert"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "domain", "_entity_value": target, "domain": target, "status": "Use Domain mode for SSL data", "source": "ssl_cert"}]
