from modules.base import BaseModule

class Module(BaseModule):
    name = "social_graph"
    category = "general"
    accepts = ["username"]

    async def run(self, target):
        return [{"_entity_type": "username", "_entity_value": target, "username": target, "status": "Social graph built by reporter", "source": "social_graph"}]
