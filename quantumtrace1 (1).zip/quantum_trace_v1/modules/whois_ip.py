from modules.base import BaseModule

class Module(BaseModule):
    name = "whois_ip"
    category = "general"
    accepts = ["ip"]

    async def run(self, target):
        return [{"_entity_type": "ip", "_entity_value": target, "ip": target, "whois_url": f"https://whois.arin.net/rest/ip/{target}", "source": "whois_ip"}]
