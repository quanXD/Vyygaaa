import aiohttp
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, extract_tg_username

class Module(BaseModule):
    name = "tg_forward"
    category = "telegram"
    accepts = ["telegram"]

    async def run(self, target):
        u = extract_tg_username(target)
        return [{
            "_entity_type": "telegram",
            "_entity_value": target,
            "target": target,
            "username": u,
            "forward_trace": "Unknown",
            "method": "heuristic",
            "note": "Forward tracing requires Telegram client",
        }]
