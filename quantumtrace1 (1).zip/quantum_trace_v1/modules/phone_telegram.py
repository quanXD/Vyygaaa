from modules.base import BaseModule
from core.utils import norm_phone

class Module(BaseModule):
    name = "phone_telegram"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        num = norm_phone(target)
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "telegram_linked": "Possible",
            "telegram_username": "@user_" + num[-4:] if len(num) >= 4 else "@unknown",
            "last_seen": "Unknown",
            "privacy": "Phone hidden",
            "method": "heuristic",
        }]
