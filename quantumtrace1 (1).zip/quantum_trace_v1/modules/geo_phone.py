from modules.base import BaseModule

class Module(BaseModule):
    name = "geo_phone"
    category = "general"
    accepts = ["phone"]

    async def run(self, target):
        return [{"_entity_type": "phone", "_entity_value": target, "phone": target, "status": "Use Phone mode for geo data", "source": "geo_phone"}]
