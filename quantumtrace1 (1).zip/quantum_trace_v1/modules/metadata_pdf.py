from modules.base import BaseModule

class Module(BaseModule):
    name = "metadata_pdf"
    category = "general"
    accepts = ["domain"]

    async def run(self, target):
        return [{"_entity_type": "general", "_entity_value": target, "target": target, "status": "PDF metadata requires file access", "source": "metadata_pdf"}]
