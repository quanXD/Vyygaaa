import aiohttp
import re
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy

class Module(BaseModule):
    name = "username_deep_recon"
    category = "username"
    accepts = ["username"]

    async def run(self, target):
        u = target.lower().strip()
        results = []
        platforms = [
            ("github", "https://github.com/" + u, "github.com/" + u),
            ("twitter", "https://twitter.com/" + u, "twitter.com/" + u),
            ("instagram", "https://www.instagram.com/" + u, "instagram.com/" + u),
            ("reddit", "https://www.reddit.com/user/" + u, "reddit.com/user/" + u),
            ("tiktok", "https://www.tiktok.com/@" + u, "tiktok.com/@" + u),
            ("linkedin", "https://www.linkedin.com/in/" + u, "linkedin.com/in/" + u),
            ("youtube", "https://www.youtube.com/@" + u, "youtube.com/@" + u),
            ("twitch", "https://www.twitch.tv/" + u, "twitch.tv/" + u),
            ("steam", "https://steamcommunity.com/id/" + u, "steamcommunity.com/id/" + u),
            ("vk", "https://vk.com/" + u, "vk.com/" + u),
        ]
        async with aiohttp.ClientSession() as s:
            for name, url, check_str in platforms:
                try:
                    st, text = await fetch(s, url, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                    status = "UNKNOWN"
                    if st == 200:
                        if "not found" in text.lower() or "does not exist" in text.lower() or "page not found" in text.lower() or "sorry" in text.lower():
                            status = "NOT FOUND"
                        else:
                            status = "FOUND"
                    elif st == 404:
                        status = "NOT FOUND"
                    elif st == 403:
                        status = "BLOCKED"
                    if status == "FOUND":
                        results.append({
                            "_entity_type": "username",
                            "_entity_value": target,
                            "username": u,
                            "platform": name,
                            "url": url,
                            "status": status,
                            "source": "deep_recon",
                        })
                except:
                    pass

            # Search for mentions
            try:
                st, text = await fetch(s, "https://html.duckduckgo.com/html/?q=\"" + u + "\"", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    urls = re.findall(r"https?://[^\s<>\"{}|\^`\[\]]+", text)
                    for found_url in set(urls)[:10]:
                        if u in found_url.lower():
                            results.append({
                                "_entity_type": "username",
                                "_entity_value": target,
                                "username": u,
                                "mention_url": found_url,
                                "source": "search_mention",
                            })
            except:
                pass

        return results if results else [{
            "_entity_type": "username",
            "_entity_value": target,
            "username": u,
            "status": "No public profiles found",
            "source": "deep_recon",
        }]
