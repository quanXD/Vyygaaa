import aiohttp
import re
import socket
import ssl
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, norm_domain

class Module(BaseModule):
    name = "domain_super_deep"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        d = norm_domain(target)
        results = []
        async with aiohttp.ClientSession() as s:
            # crt.sh extended
            try:
                st, text = await fetch(s, "https://crt.sh/?q=%." + d + "&output=json", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=15)
                if st == 200:
                    import json
                    data = json.loads(text)
                    seen = set()
                    for entry in data[:200]:
                        name = entry.get("name_value", "").strip()
                        if name and name not in seen:
                            seen.add(name)
                            results.append({
                                "_entity_type": "domain",
                                "_entity_value": target,
                                "subdomain": name,
                                "issuer": entry.get("issuer_name", "N/A"),
                                "source": "crt.sh",
                            })
            except:
                pass

            # DNS records
            import dns.resolver
            for rtype in ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME", "SRV", "PTR"]:
                try:
                    answers = dns.resolver.resolve(d, rtype)
                    for ans in answers:
                        results.append({
                            "_entity_type": "domain",
                            "_entity_value": target,
                            "type": rtype,
                            "value": str(ans),
                            "source": "dns",
                        })
                except:
                    pass

            # Website scrape
            try:
                st, text = await fetch(s, "https://" + d, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    tech = []
                    checks = [
                        ("WordPress", ["wp-content", "wordpress"]),
                        ("Drupal", ["drupal"]),
                        ("Joomla", ["joomla"]),
                        ("React", ["react"]),
                        ("Vue.js", ["vue"]),
                        ("Angular", ["angular"]),
                        ("Laravel", ["laravel"]),
                        ("Django", ["django"]),
                        ("Next.js", ["_next", "next.js"]),
                        ("Nginx", ["nginx"]),
                        ("Apache", ["apache"]),
                        ("Cloudflare", ["cloudflare"]),
                        ("AWS", ["aws", "amazonaws"]),
                        ("Shopify", ["shopify"]),
                        ("Wix", ["wix"]),
                        ("Squarespace", ["squarespace"]),
                    ]
                    for name, keywords in checks:
                        for kw in keywords:
                            if kw in text.lower():
                                tech.append(name)
                                break
                    emails = list(set(re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)))
                    for email in emails[:15]:
                        results.append({
                            "_entity_type": "email",
                            "_entity_value": email,
                            "email": email,
                            "found_on": d,
                            "source": "web_scrape",
                        })
                    if tech:
                        results.append({
                            "_entity_type": "domain",
                            "_entity_value": target,
                            "domain": d,
                            "tech_stack": ", ".join(list(set(tech))),
                            "source": "tech_scan",
                        })
            except:
                pass

            # SSL
            try:
                ctx = ssl.create_default_context()
                with socket.create_connection((d, 443), timeout=8) as sock:
                    with ctx.wrap_socket(sock, server_hostname=d) as ssock:
                        cert = ssock.getpeercert()
                        alt = ", ".join([x[1] for x in cert.get("subjectAltName", [])])
                        results.append({
                            "_entity_type": "domain",
                            "_entity_value": target,
                            "domain": d,
                            "issuer": str(cert.get("issuer")),
                            "alt_names": alt,
                            "not_after": str(cert.get("notAfter")),
                            "tls_version": ssock.version(),
                            "source": "ssl",
                        })
            except:
                pass

            # Wayback
            try:
                st, text = await fetch(s, "https://web.archive.org/cdx/search/cdx?url=" + d + "&output=json&collapse=urlkey", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        for snap in data[1:8]:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "domain",
                                    "_entity_value": target,
                                    "snapshot": "https://web.archive.org/web/" + snap[1] + "/" + snap[2],
                                    "date": snap[1],
                                    "source": "wayback",
                                })
            except:
                pass

            # Resolve IP
            try:
                ip = socket.gethostbyname(d)
                results.append({
                    "_entity_type": "ip",
                    "_entity_value": ip,
                    "domain": d,
                    "ip": ip,
                    "source": "dns_resolve",
                })
            except:
                pass

        return results if results else [{
            "_entity_type": "domain",
            "_entity_value": target,
            "domain": d,
            "status": "Limited public data",
            "source": "super_deep",
        }]
