import aiohttp
import re
import socket
import ssl
from modules.base import BaseModule
from core.utils import fetch, get_ua, get_proxy, norm_domain

class Module(BaseModule):
    name = "domain_deep_recon"
    category = "domain"
    accepts = ["domain"]

    async def run(self, target):
        d = norm_domain(target)
        results = []
        async with aiohttp.ClientSession() as s:
            # crt.sh deep
            try:
                st, text = await fetch(s, "https://crt.sh/?q=%." + d + "&output=json", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=15)
                if st == 200:
                    import json
                    data = json.loads(text)
                    seen = set()
                    for entry in data[:100]:
                        name = entry.get("name_value", "").strip()
                        if name and name not in seen:
                            seen.add(name)
                            results.append({
                                "_entity_type": "domain",
                                "_entity_value": target,
                                "subdomain": name,
                                "issuer": entry.get("issuer_name", "N/A"),
                                "source": "crt.sh",
                            })
            except:
                pass

            # Tech stack
            try:
                st, text = await fetch(s, "https://" + d, headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=10)
                if st == 200:
                    tech = []
                    if "wp-content" in text or "wordpress" in text.lower():
                        tech.append("WordPress")
                    if "drupal" in text.lower():
                        tech.append("Drupal")
                    if "joomla" in text.lower():
                        tech.append("Joomla")
                    if "react" in text.lower():
                        tech.append("React")
                    if "vue" in text.lower():
                        tech.append("Vue.js")
                    if "angular" in text.lower():
                        tech.append("Angular")
                    if "laravel" in text.lower():
                        tech.append("Laravel")
                    if "django" in text.lower():
                        tech.append("Django")
                    if "next.js" in text.lower() or "_next" in text.lower():
                        tech.append("Next.js")
                    if "nginx" in text.lower():
                        tech.append("Nginx")
                    if "apache" in text.lower():
                        tech.append("Apache")
                    if "cloudflare" in text.lower():
                        tech.append("Cloudflare")
                    emails = list(set(re_mod.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)))
                    for email in emails[:10]:
                        results.append({
                            "_entity_type": "email",
                            "_entity_value": email,
                            "email": email,
                            "found_on": d,
                            "source": "web_scrape",
                        })
                    if tech:
                        results.append({
                            "_entity_type": "domain",
                            "_entity_value": target,
                            "domain": d,
                            "tech_stack": ", ".join(tech),
                            "source": "tech_scan",
                        })
            except:
                pass

            # SSL cert
            try:
                ctx = ssl.create_default_context()
                with socket.create_connection((d, 443), timeout=8) as sock:
                    with ctx.wrap_socket(sock, server_hostname=d) as ssock:
                        cert = ssock.getpeercert()
                        alt = ", ".join([x[1] for x in cert.get("subjectAltName", [])])
                        results.append({
                            "_entity_type": "domain",
                            "_entity_value": target,
                            "domain": d,
                            "issuer": str(cert.get("issuer")),
                            "alt_names": alt,
                            "not_after": str(cert.get("notAfter")),
                            "tls_version": ssock.version(),
                            "source": "ssl",
                        })
            except:
                pass

            # Wayback
            try:
                st, text = await fetch(s, "https://web.archive.org/cdx/search/cdx?url=" + d + "&output=json&collapse=urlkey", headers={"User-Agent": get_ua()}, proxy=get_proxy(), timeout=12)
                if st == 200 and text:
                    import json
                    data = json.loads(text)
                    if isinstance(data, list) and len(data) > 1:
                        for snap in data[1:6]:
                            if len(snap) >= 4:
                                results.append({
                                    "_entity_type": "domain",
                                    "_entity_value": target,
                                    "snapshot": "https://web.archive.org/web/" + snap[1] + "/" + snap[2],
                                    "date": snap[1],
                                    "source": "wayback",
                                })
            except:
                pass

        return results if results else [{
            "_entity_type": "domain",
            "_entity_value": target,
            "domain": d,
            "status": "Limited public data",
            "source": "deep_recon",
        }]
