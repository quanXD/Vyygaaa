from modules.base import BaseModule

class Module(BaseModule):
    name = "ip_history"
    category = "ip"
    accepts = ["ip"]

    async def run(self, target):
        return [{
            "_entity_type": "ip",
            "_entity_value": target,
            "ip": target,
            "history_url": f"https://viewdns.info/reverseip/?host={target}&t=1",
            "source": "viewdns",
        }]
