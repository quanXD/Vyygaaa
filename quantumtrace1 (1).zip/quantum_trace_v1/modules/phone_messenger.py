from modules.base import BaseModule

class Module(BaseModule):
    name = "phone_messenger"
    category = "phone"
    accepts = ["phone"]

    async def run(self, target):
        return [{
            "_entity_type": "phone",
            "_entity_value": target,
            "phone": target,
            "whatsapp": f"https://wa.me/{target.replace('+', '').replace(' ', '').replace('-', '')}",
            "telegram": "Possible",
            "viber": "Possible",
            "source": "messenger",
        }]
