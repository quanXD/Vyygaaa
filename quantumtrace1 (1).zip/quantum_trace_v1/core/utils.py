import random
import hashlib
import re
import ipaddress
import asyncio
from datetime import datetime

def get_ua():
    from config import USER_AGENTS
    return random.choice(USER_AGENTS)

def get_proxy():
    from config import PROXIES
    return random.choice(PROXIES) if PROXIES else None

def md5(val):
    return hashlib.md5(str(val).encode()).hexdigest()

def sha1(val):
    return hashlib.sha1(str(val).encode()).hexdigest()

def sha256(val):
    return hashlib.sha256(str(val).encode()).hexdigest()

def is_ip(val):
    try:
        ipaddress.ip_address(val)
        return True
    except:
        return False

def is_email(val):
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(val)))

def is_phone(val):
    return bool(re.match(r"^[\+]?[0-9\s\-\(\)]{7,20}$", str(val)))

def norm_domain(val):
    v = str(val).lower().strip()
    v = v.replace("http://", "").replace("https://", "").strip("/")
    return v

def norm_phone(val):
    return re.sub(r"[^0-9+]", "", str(val))

def timestamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")

def ts_human():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def detect_type(val):
    v = str(val).strip()
    if is_phone(v):
        return "phone"
    if is_email(v):
        return "email"
    if is_ip(v):
        return "ip"
    if v.startswith("@") or v.startswith("t.me/"):
        return "telegram"
    if "." in v and not v.startswith("http") and "/" not in v:
        return "domain"
    return "username"

async def fetch(session, url, headers=None, proxy=None, timeout=12, retries=2):
    from aiohttp_socks import ProxyConnector
    for attempt in range(retries):
        try:
            if proxy and proxy.startswith("socks"):
                connector = ProxyConnector.from_url(proxy)
                async with aiohttp.ClientSession(connector=connector) as s:
                    async with s.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout)) as r:
                        return r.status, await r.text()
            else:
                async with session.get(url, headers=headers, timeout=aiohttp.ClientTimeout(total=timeout), proxy=proxy) as r:
                    return r.status, await r.text()
        except Exception:
            if attempt < retries - 1:
                await asyncio.sleep(1.5 ** attempt)
    return 0, ""

async def fetch_json(session, url, headers=None, proxy=None, timeout=12, retries=2):
    st, text = await fetch(session, url, headers, proxy, timeout, retries)
    if st == 200 and text:
        try:
            import json
            return json.loads(text)
        except:
            pass
    return None

def extract_tg_username(target):
    t = str(target).strip()
    t = t.replace("https://", "").replace("http://", "")
    t = t.replace("t.me/", "").replace("telegram.me/", "").replace("tg.me/", "")
    t = t.replace("@", "").strip()
    t = re.sub(r"[^a-zA-Z0-9_]", "", t)
    return t

def tg_variations(username):
    u = username.lower()
    base = re.sub(r"[^a-z0-9]", "", u)
    out = {u, base}
    out.add(base + "_official")
    out.add(base + "_bot")
    out.add(base + "_news")
    out.add(base + "_channel")
    out.add("_".join(base.split()) if " " in base else base)
    out.add(base.replace("_", ""))
    out.add(base.replace("_", "-"))
    if len(base) > 3:
        out.add(base + "s")
        out.add(base + "1")
        out.add(base + "2")
        out.add(base + "0")
    return list(out)

def extract_emails(text):
    return list(set(re.findall(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}", text)))

def extract_phones(text):
    return list(set(re.findall(r"[\+]?[1-9]?[0-9]{7,15}", re.sub(r"[^\d+]", "", text))))

def extract_urls(text):
    return list(set(re.findall(r"https?://[^\s<>\"{}|\^`\[\]]+", text)))

def extract_ips(text):
    return list(set(re.findall(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b", text)))
