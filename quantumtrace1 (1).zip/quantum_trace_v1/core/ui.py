from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from config import SEARCH_MODES, THEME

class QuantumUI:
    def __init__(self):
        self.c = Console()

    def banner(self):
        art = r"""
   _____                       _                      _____                          
 |  _  |                     | |                    |_   _|                         
 | | | | _   _   __ _  _ __  | |_  _   _  _ __ ___    | |   _ __   __ _   ___   ___ 
 | | | || | | | / _` || '_ \ | __|| | | || '_ ` _ \   | |  | '__| / _` | / __| / _ \
 \ \/' /| |_| || (_| || | | || |_ | |_| || | | | | |  | |  | |   | (_| || (__ |  __/
  \_/\_\ \__,_| \__,_||_| |_| \__| \__,_||_| |_| |_|  \_/  |_|    \__,_| \___| \___|
        """
        self.c.print("[bold " + THEME["primary"] + "]" + art + "[/]")
        self.c.print("[bold " + THEME["gold"] + "]QuantumTrace v1.0 [/]")
        self.c.print("[" + THEME["muted"] + "] 134 modules[/]\n")

    def main_menu(self):
        items = ""
        for k, v in SEARCH_MODES.items():
            items += "[" + k + "] " + v["icon"] + " " + v["name"] + "\n"
        items += "[8] Settings\n[9] History\n[0] Exit"
        self.c.print(Panel.fit(items, title="[bold]SELECT TARGET TYPE[/bold]", border_style=THEME["primary"]))
        return self.c.input("[" + THEME["primary"] + "]>> [/]").strip()

    def ask_target(self, mode_name):
        self.c.print("\n[" + THEME["warning"] + "]Enter target for " + mode_name + " recon:[/]")
        return self.c.input("[" + THEME["primary"] + "]Target >> [/]").strip()

    def result_table(self, title, rows, columns):
        if not rows:
            return
        t = Table(title=title, show_header=True, header_style="bold " + THEME["primary"])
        for col in columns:
            t.add_column(col)
        for row in rows:
            t.add_row(*[str(row.get(c, "")) for c in columns])
        self.c.print(t)

    def display_grouped(self, results):
        from collections import defaultdict
        grouped = defaultdict(lambda: defaultdict(list))
        for mod_name, items in results.items():
            if not items:
                continue
            cat = items[0].get("_entity_type", "unknown")
            grouped[cat][mod_name] = items

        for cat in sorted(grouped.keys()):
            total = sum(len(v) for v in grouped[cat].values())
            self.c.print("\n[bold " + THEME["gold"] + "]=== " + cat.upper() + " (" + str(total) + ") ===[/]")
            for mod_name in sorted(grouped[cat].keys()):
                items = grouped[cat][mod_name]
                cols = [k for k in items[0].keys() if not k.startswith("_")] if items else []
                if not cols:
                    continue
                self.result_table("  [" + mod_name + "] " + str(len(items)) + " result(s)", items, cols)

    def final_stats(self, stats, paths, correlations):
        self.c.print("\n[bold " + THEME["gold"] + "]=== EXECUTION COMPLETE ===[/]")
        self.c.print("[" + THEME["success"] + "]Modules run: " + str(stats["modules"]) + "[/]")
        self.c.print("[" + THEME["success"] + "]Entities found: " + str(stats["entities"]) + "[/]")
        self.c.print("[" + THEME["success"] + "]Elapsed: " + str(stats["elapsed"]) + "s[/]")
        self.c.print("[" + THEME["info"] + "]Correlations found: " + str(correlations) + "[/]")
        for label, path in paths.items():
            self.c.print("[" + THEME["info"] + "]" + label + ": " + str(path) + "[/]")

    def alert(self, msg, level="info"):
        self.c.print("[" + THEME.get(level, "white") + "]" + msg + "[/]")
