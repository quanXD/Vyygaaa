import json
from pathlib import Path
from config import REPORTS_DIR
from core.utils import timestamp
from core.db import QuantumDB

class Reporter:
    def __init__(self, scan_id):
        self.scan_id = scan_id
        self.db = QuantumDB()

    def save_json(self, target, mode_name):
        path = REPORTS_DIR / ("qt_" + mode_name.lower().replace(" ", "_") + "_" + target.replace("/", "_").replace("@", "at") + "_" + timestamp() + ".json")
        payload = self._build_payload(target, mode_name)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2, ensure_ascii=False)
        return path

    def save_html(self, target, mode_name):
        stem = "qt_" + mode_name.lower().replace(" ", "_") + "_" + target.replace("/", "_").replace("@", "at") + "_" + timestamp()
        path = REPORTS_DIR / (stem + ".html")
        graph_path = REPORTS_DIR / (stem + "_graph.html")
        html = self._build_html(target, mode_name, graph_path.name)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        self._save_graph(target, mode_name, graph_path)
        return path

    def _save_graph(self, target, mode_name, path):
        ents = self.db.get_entities(self.scan_id)
        corrs = self.db.get_correlations(self.scan_id)
        colors = {
            "phone": "#00ff88", "email": "#4488ff", "domain": "#ffcc00",
            "ip": "#ff3366", "username": "#ffd700", "telegram": "#00d4ff",
            "unknown": "#888888"
        }
        nodes = []
        links = []
        seen = set()
        for e in ents:
            val = e.get("value", "")
            et = e.get("entity_type", "unknown")
            if val and val not in seen:
                seen.add(val)
                nodes.append({"id": val, "group": et, "color": colors.get(et, "#888")})
        for c in corrs:
            fv = c.get("from_value", "")
            tv = c.get("to_value", "")
            if fv in seen and tv in seen:
                links.append({"source": fv, "target": tv, "label": c.get("link_type", "link")})

        nodes_json = json.dumps(nodes)
        links_json = json.dumps(links)
        total_ents = len(ents)
        total_corrs = len(corrs)

        html = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>QuantumTrace Network Graph</title>
<style>
body{background:#0a0a0f;color:#c0c0d0;font-family:'Segoe UI',monospace;margin:0;overflow:hidden}
header{background:#111118;border-bottom:1px solid #222;padding:15px 25px}
header h1{color:#00d4ff;font-size:22px;margin:0}
header .meta{color:#666;font-size:12px;margin-top:4px}
#graph{width:100vw;height:calc(100vh - 60px);background:#0a0a0f}
.tooltip{position:absolute;background:#111118;border:1px solid #333;padding:8px 12px;border-radius:4px;font-size:12px;color:#00d4ff;pointer-events:none;opacity:0;transition:opacity .2s;z-index:1000}
.controls{position:fixed;bottom:20px;right:20px;background:#111118;border:1px solid #222;padding:10px 15px;border-radius:6px;font-size:12px}
.controls button{background:#1a1a2e;color:#00d4ff;border:1px solid #333;padding:5px 12px;margin:2px;border-radius:4px;cursor:pointer}
.controls button:hover{background:#222}
</style></head>
<body>
<header><h1>QuantumTrace v1.0 — Network Graph</h1><div class="meta">Target: """ + target + """ | Mode: """ + mode_name + """ | Nodes: """ + str(total_ents) + """ | Links: """ + str(total_corrs) + """</div></header>
<div id="graph"></div>
<div class="tooltip" id="tooltip"></div>
<div class="controls">
<button onclick="resetZoom()">Reset</button>
<button onclick="toggleLabels()">Labels</button>
</div>
<script src="https://d3js.org/d3.v7.min.js"></script>
<script>
var nodes = """ + nodes_json + """;
var links = """ + links_json + """;
var width = window.innerWidth;
var height = window.innerHeight - 60;
var svg = d3.select("#graph").append("svg").attr("width", width).attr("height", height);
var g = svg.append("g");
var zoom = d3.zoom().scaleExtent([0.1, 4]).on("zoom", function(event){ g.attr("transform", event.transform); });
svg.call(zoom);
var simulation = d3.forceSimulation(nodes)
  .force("link", d3.forceLink(links).id(function(d){ return d.id; }).distance(120))
  .force("charge", d3.forceManyBody().strength(-500))
  .force("center", d3.forceCenter(width / 2, height / 2))
  .force("collide", d3.forceCollide().radius(25));
var link = g.append("g").selectAll("line").data(links).join("line")
  .attr("stroke", "#444").attr("stroke-width", 1.5).attr("stroke-opacity", 0.6);
var node = g.append("g").selectAll("g").data(nodes).join("g")
  .call(d3.drag().on("start", dragstarted).on("drag", dragged).on("end", dragended));
node.append("circle").attr("r", 12).attr("fill", function(d){ return d.color; }).attr("stroke", "#fff").attr("stroke-width", 1.5)
  .on("mouseover", function(event, d){ tooltip.style.opacity=1; tooltip.innerHTML="<strong>"+d.id+"</strong><br>Type: "+d.group; tooltip.style.left=(event.pageX+10)+"px"; tooltip.style.top=(event.pageY+10)+"px"; d3.select(this).attr("r", 18).attr("stroke", "#00d4ff"); })
  .on("mouseout", function(event, d){ tooltip.style.opacity=0; d3.select(this).attr("r", 12).attr("stroke", "#fff"); });
var labels = g.append("g").selectAll("text").data(nodes).join("text")
  .text(function(d){ return d.id; }).attr("x", 16).attr("y", 4).attr("fill", "#bbb").attr("font-size", "11px").attr("font-family", "monospace").attr("pointer-events", "none");
simulation.on("tick", function(){
  link.attr("x1", function(d){ return d.source.x; }).attr("y1", function(d){ return d.source.y; }).attr("x2", function(d){ return d.target.x; }).attr("y2", function(d){ return d.target.y; });
  node.attr("transform", function(d){ return "translate("+d.x+","+d.y+")"; });
  labels.attr("x", function(d){ return d.x + 14; }).attr("y", function(d){ return d.y + 4; });
});
function dragstarted(event, d){ if(!event.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; }
function dragged(event, d){ d.fx = event.x; d.fy = event.y; }
function dragended(event, d){ if(!event.active) simulation.alphaTarget(0); d.fx = null; d.fy = null; }
function resetZoom(){ svg.transition().duration(750).call(zoom.transform, d3.zoomIdentity); }
var labelsVisible = true;
function toggleLabels(){ labelsVisible = !labelsVisible; labels.style("opacity", labelsVisible ? 1 : 0); }
var tooltip = document.getElementById("tooltip");
</script></body></html>"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)

    def _build_payload(self, target, mode_name):
        ents = self.db.get_entities(self.scan_id)
        corrs = self.db.get_correlations(self.scan_id)
        grouped = self._group_entities(ents)
        return {
            "scan_info": {
                "target": target,
                "mode": mode_name,
                "scan_id": self.scan_id,
                "generated": timestamp(),
            },
            "summary": {
                "total_modules": len(set(e.get("module", "") for e in ents)),
                "total_entities": len(ents),
                "total_correlations": len(corrs),
                "by_category": {k: len(v) for k, v in grouped.items()},
            },
            "correlations": corrs,
            "results": grouped,
        }

    def _group_entities(self, ents):
        groups = {}
        for e in ents:
            cat = e.get("entity_type", "unknown")
            mod = e.get("module", "unknown")
            if cat not in groups:
                groups[cat] = {}
            if mod not in groups[cat]:
                groups[cat][mod] = []
            try:
                data = json.loads(e.get("data", "{}"))
            except:
                data = {}
            groups[cat][mod].append(data)
        return groups

    def _clean_value(self, val):
        if val is None:
            return ""
        bad = ["N/A", "Unknown", "n/a", "unknown", "None", "none", "", " ", "No data", "failed"]
        return str(val) if str(val) not in bad else ""

    def _filter_dict(self, d):
        if not isinstance(d, dict):
            return d
        return {k: self._filter_dict(v) for k, v in d.items() if self._clean_value(v) != ""}

    def _build_html(self, target, mode_name, graph_filename):
        ents = self.db.get_entities(self.scan_id)
        corrs = self.db.get_correlations(self.scan_id)
        grouped = self._group_entities(ents)

        nav_items = ""
        for cat in sorted(grouped.keys()):
            nav_items += '<a href="#cat_' + cat + '" class="nav-item">' + cat.upper() + " (" + str(sum(len(v) for v in grouped[cat].values())) + ")</a>"

        sections = ""
        for cat in sorted(grouped.keys()):
            sections += '<section id="cat_' + cat + '" class="category">'
            sections += '<h2><span class="badge">' + str(sum(len(v) for v in grouped[cat].values())) + '</span> ' + cat.upper() + "</h2>"
            for mod in sorted(grouped[cat].keys()):
                items = grouped[cat][mod]
                clean_items = [self._filter_dict(item) for item in items]
                clean_items = [item for item in clean_items if item]
                if not clean_items:
                    continue
                sections += '<div class="module-box">'
                sections += '<h3>' + mod + ' <span class="count">' + str(len(clean_items)) + "</span></h3>"
                sections += '<div class="grid">'
                for item in clean_items:
                    sections += '<div class="card">'
                    for k, v in sorted(item.items()):
                        if k.startswith("_"):
                            continue
                        sections += '<div class="row"><span class="key">' + k + ':</span> <span class="val">' + str(v)[:500] + "</span></div>"
                    sections += "</div>"
                sections += "</div></div>"
            sections += "</section>"

        corr_html = ""
        if corrs:
            corr_html = '<section class="category"><h2>CORRELATIONS (' + str(len(corrs)) + ')</h2><div class="corr-grid">'
            for c in corrs:
                corr_html += '<div class="corr-card"><strong>' + c.get("from_value", "") + '</strong> <span class="arrow">&rarr;</span> <strong>' + c.get("to_value", "") + '</strong><br><span class="link-type">' + c.get("link_type", "") + "</span></div>"
            corr_html += "</div></section>"

        total_mods = len(set(e.get("module", "") for e in ents))
        total_ents = len(ents)
        total_corrs = len(corrs)
        total_cats = len(grouped)

        return """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>QuantumTrace v1.0</title>
<style>
:root{--bg:#0a0a0f;--panel:#111118;--border:#222;--text:#c0c0d0;--accent:#00d4ff;--gold:#ffd700;--green:#00ff88;--red:#ff4444}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',monospace;line-height:1.5}
header{background:var(--panel);border-bottom:1px solid var(--border);padding:20px 30px;position:sticky;top:0;z-index:100}
header h1{color:var(--accent);font-size:28px}
header .meta{color:#666;font-size:13px;margin-top:5px}
.container{display:flex;min-height:100vh}
.sidebar{width:240px;background:var(--panel);border-right:1px solid var(--border);padding:20px;position:sticky;top:70px;height:calc(100vh - 70px);overflow-y:auto}
.sidebar h3{color:var(--gold);font-size:14px;text-transform:uppercase;margin-bottom:15px;letter-spacing:1px}
.nav-item{display:block;color:#888;text-decoration:none;padding:8px 12px;border-radius:4px;margin-bottom:4px;font-size:13px;transition:.2s}
.nav-item:hover{background:#1a1a2e;color:var(--accent)}
.main{flex:1;padding:30px}
.summary{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:15px;margin-bottom:30px}
.sum-card{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:20px;text-align:center}
.sum-card .num{font-size:32px;font-weight:bold;color:var(--accent)}
.sum-card .label{font-size:12px;color:#666;text-transform:uppercase;margin-top:5px}
.graph-link{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:15px;margin-bottom:25px;text-align:center}
.graph-link a{color:var(--accent);text-decoration:none;font-size:15px;font-weight:bold}
.graph-link a:hover{text-decoration:underline}
.category{margin-bottom:40px}
.category h2{color:var(--gold);font-size:20px;margin-bottom:20px;display:flex;align-items:center;gap:10px}
.badge{background:var(--accent);color:#000;padding:2px 10px;border-radius:12px;font-size:13px;font-weight:bold}
.module-box{background:var(--panel);border:1px solid var(--border);border-radius:8px;padding:20px;margin-bottom:20px}
.module-box h3{color:var(--text);font-size:15px;margin-bottom:15px;display:flex;align-items:center;gap:10px}
.module-box .count{background:#1a1a2e;color:#888;padding:2px 8px;border-radius:10px;font-size:12px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:15px}
.card{background:#0d0d14;border:1px solid #1a1a2e;border-radius:6px;padding:15px;font-size:13px}
.card .row{margin-bottom:6px}
.card .key{color:var(--accent);font-weight:600}
.card .val{color:#aaa;word-break:break-all}
.corr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:15px}
.corr-card{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:15px;text-align:center}
.corr-card .arrow{color:var(--accent);font-size:20px;margin:0 10px}
.corr-card .link-type{color:#666;font-size:12px;text-transform:uppercase}
.empty{color:#444;font-style:italic;text-align:center;padding:40px}
@media(max-width:900px){.sidebar{display:none}.main{padding:15px}}
</style></head>
<body>
<header><h1>QuantumTrace v1.0</h1><div class="meta">Target: """ + target + """ | Mode: """ + mode_name + """ | Entities: """ + str(total_ents) + """ | Correlations: """ + str(total_corrs) + """</div></header>
<div class="container">
<div class="sidebar"><h3>Categories</h3>""" + nav_items + """<h3 style="margin-top:30px">Graph</h3><a href=""" + '"' + graph_filename + '"' + """ class="nav-item" target="_blank">Open Network Graph</a></div>
<div class="main">
<div class="summary">
<div class="sum-card"><div class="num">""" + str(total_mods) + """</div><div class="label">Modules</div></div>
<div class="sum-card"><div class="num">""" + str(total_ents) + """</div><div class="label">Entities</div></div>
<div class="sum-card"><div class="num">""" + str(total_corrs) + """</div><div class="label">Links</div></div>
<div class="sum-card"><div class="num">""" + str(total_cats) + """</div><div class="label">Categories</div></div>
</div>
<div class="graph-link"><a href=""" + '"' + graph_filename + '"' + """ target="_blank">&#128279; Open Interactive Network Graph</a></div>
""" + sections + corr_html + """
</div></div>
</body></html>"""
