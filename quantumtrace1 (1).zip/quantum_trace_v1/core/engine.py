import asyncio
import importlib.util
import json
from pathlib import Path
from typing import Dict, List, Any
from config import SEARCH_MODES, THREADS, CHAIN_DEPTH
from core.logger import setup_logger
from core.utils import timestamp, detect_type
from core.db import QuantumDB

log = setup_logger()

class QuantumEngine:
    def __init__(self):
        self.results: Dict[str, List[Dict]] = {}
        self.stats = {"entities": 0, "modules": 0, "elapsed": 0.0}
        self.modules = {}
        self.db = QuantumDB()
        self.scan_id = None
        self._load_modules()

    def _load_modules(self):
        d = Path(__file__).parent.parent / "modules"
        for f in d.glob("*.py"):
            if f.name.startswith("_"):
                continue
            try:
                spec = importlib.util.spec_from_file_location("modules." + f.stem, f)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                if hasattr(mod, "Module"):
                    self.modules[f.stem] = mod.Module()
            except Exception as e:
                log.warning("Load fail " + f.stem + ": " + str(e))

    def _is_valid_result(self, item):
        if not isinstance(item, dict):
            return False
        bad_vals = ["N/A", "Unknown", "n/a", "unknown", "None", "none", "", " ", "No data", "failed", "failed"]
        has_data = False
        for k, v in item.items():
            if k.startswith("_"):
                continue
            if isinstance(v, str) and v.strip() not in bad_vals:
                has_data = True
            elif isinstance(v, (int, float, bool, list)) and v:
                has_data = True
            elif isinstance(v, dict) and v:
                has_data = True
        return has_data

    def _dedupe_results(self, results):
        seen = set()
        out = []
        for r in results:
            key = json.dumps(r, sort_keys=True, ensure_ascii=False)
            if key not in seen:
                seen.add(key)
                out.append(r)
        return out

    async def run_module(self, name: str, target: str) -> List[Dict]:
        mod = self.modules.get(name)
        if not mod:
            return []
        try:
            result = await mod.run(target)
            self.stats["modules"] += 1
            if isinstance(result, list):
                result = [r for r in result if self._is_valid_result(r)]
                result = self._dedupe_results(result)
                self.stats["entities"] += len(result)
                for item in result:
                    if isinstance(item, dict):
                        et = item.get("_entity_type", mod.category)
                        ev = item.get("_entity_value", target)
                        self.db.add_entity(self.scan_id, name, et, ev, item)
            return result
        except Exception as e:
            log.error("Run fail " + name + ": " + str(e))
            return []

    async def run_mode(self, mode_key: str, target: str) -> Dict[str, Any]:
        import time
        start = time.time()
        mode = SEARCH_MODES.get(mode_key)
        if not mode:
            return {}
        target_type = detect_type(target)
        self.scan_id = self.db.new_scan(target, target_type, mode["name"])
        accepted = [n for n, m in self.modules.items() if target_type in getattr(m, "accepts", [])]
        if mode_key == "7":
            to_run = accepted
        else:
            to_run = accepted
        semaphore = asyncio.Semaphore(THREADS)

        async def bounded(m):
            async with semaphore:
                return m, await self.run_module(m, target)

        tasks = [bounded(m) for m in to_run]
        raw = await asyncio.gather(*tasks)
        self.stats["elapsed"] = round(time.time() - start, 2)
        for name, data in raw:
            if data:
                self.results[name] = data

        if CHAIN_DEPTH > 0:
            await self._chain_enrich(target, target_type, CHAIN_DEPTH)

        self._correlate()
        self.db.finish_scan(self.scan_id, self.stats)
        return self.results

    async def _chain_enrich(self, target, target_type, depth):
        if depth <= 0:
            return
        new_targets = []
        if target_type == "domain":
            emails = self.db.get_values_by_type(self.scan_id, "email")
            ips = self.db.get_values_by_type(self.scan_id, "ip")
            usernames = self.db.get_values_by_type(self.scan_id, "username")
            new_targets.extend([(e, "email") for e in emails[:8]])
            new_targets.extend([(i, "ip") for i in ips[:8]])
            new_targets.extend([(u, "username") for u in usernames[:5]])
        elif target_type == "email":
            domains = self.db.get_values_by_type(self.scan_id, "domain")
            usernames = self.db.get_values_by_type(self.scan_id, "username")
            phones = self.db.get_values_by_type(self.scan_id, "phone")
            new_targets.extend([(d, "domain") for d in domains[:8]])
            new_targets.extend([(u, "username") for u in usernames[:5]])
            new_targets.extend([(p, "phone") for p in phones[:3]])
        elif target_type == "username":
            emails = self.db.get_values_by_type(self.scan_id, "email")
            domains = self.db.get_values_by_type(self.scan_id, "domain")
            tgs = self.db.get_values_by_type(self.scan_id, "telegram")
            new_targets.extend([(e, "email") for e in emails[:5]])
            new_targets.extend([(d, "domain") for d in domains[:5]])
            new_targets.extend([(t, "telegram") for t in tgs[:5]])
        elif target_type == "telegram":
            usernames = self.db.get_values_by_type(self.scan_id, "username")
            phones = self.db.get_values_by_type(self.scan_id, "phone")
            emails = self.db.get_values_by_type(self.scan_id, "email")
            new_targets.extend([(u, "username") for u in usernames[:8]])
            new_targets.extend([(p, "phone") for p in phones[:3]])
            new_targets.extend([(e, "email") for e in emails[:3]])
        elif target_type == "phone":
            usernames = self.db.get_values_by_type(self.scan_id, "username")
            emails = self.db.get_values_by_type(self.scan_id, "email")
            tgs = self.db.get_values_by_type(self.scan_id, "telegram")
            new_targets.extend([(u, "username") for u in usernames[:5]])
            new_targets.extend([(e, "email") for e in emails[:5]])
            new_targets.extend([(t, "telegram") for t in tgs[:3]])
        elif target_type == "ip":
            domains = self.db.get_values_by_type(self.scan_id, "domain")
            new_targets.extend([(d, "domain") for d in domains[:8]])

        semaphore = asyncio.Semaphore(THREADS)
        for nt, nt_type in new_targets:
            accepted = [n for n, m in self.modules.items() if nt_type in getattr(m, "accepts", [])]
            async def bounded2(m, t=nt):
                async with semaphore:
                    return m, await self.run_module(m, t)
            tasks2 = [bounded2(m) for m in accepted]
            raw2 = await asyncio.gather(*tasks2)
            for name, data in raw2:
                if data:
                    self.results[name] = self.results.get(name, []) + data
        await self._chain_enrich(target, target_type, depth - 1)

    def _correlate(self):
        ents = self.db.get_entities(self.scan_id)
        values = {e.get("value", ""): e.get("entity_type", "") for e in ents}
        seen = set()
        for e in ents:
            val = e.get("value", "")
            et = e.get("entity_type", "")
            try:
                data = json.loads(e.get("data", "{}"))
            except:
                data = {}
            for k, v in data.items():
                if isinstance(v, str) and v in values and v != val and v.strip():
                    pair = tuple(sorted([val, v]))
                    if pair not in seen:
                        seen.add(pair)
                        self.db.add_correlation(self.scan_id, val, v, et + "_" + k)
